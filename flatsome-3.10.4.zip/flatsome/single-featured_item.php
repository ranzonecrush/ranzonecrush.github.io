<?php

get_header(); ?>

<div class="portfolio-page-wrapper portfolio-single-page">
	<?php get_template_part('template-parts/portfolio/single-portfolio', flatsome_option('portfolio_layout')); ?>
</div>

<?php get_footer(); ?>